﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Đồ_Án_2019
{
    public partial class InHoaDonCu : Form
    {
        public InHoaDonCu()
        {
            InitializeComponent();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
        private void InHoaDonCu_Load(object sender, EventArgs e)
        {
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Đồ_Án_2019.HoaDon.rdlc";
            dsHoaDon.V_ChiTietHoaDon_SanPhamDataTable ChiTietHoaDon = new dsHoaDon.V_ChiTietHoaDon_SanPhamDataTable();
            dsHoaDonTableAdapters.V_ChiTietHoaDon_SanPhamTableAdapter HoaDon = new dsHoaDonTableAdapters.V_ChiTietHoaDon_SanPhamTableAdapter();
            this.reportViewer1.LocalReport.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource("DataSet2", (DataTable)ChiTietHoaDon));
            HoaDon.FillByMaHD(ChiTietHoaDon,Admin.MaHDHT);
            this.reportViewer1.RefreshReport();
        }
    }
}
