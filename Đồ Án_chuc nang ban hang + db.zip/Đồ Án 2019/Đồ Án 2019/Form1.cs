﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BAL;
using BEL;
namespace Đồ_Án_2019
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public BEL_NHANVIEN nv = new BEL_NHANVIEN();
        public static BEL_NHANVIEN nhanvien = new BEL_NHANVIEN();
        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string taikhoan = txtUserName.Text;
                string matkhau = txtPassWord.Text;
                BAL_NHANVIEN XuLyDangNhap = new BAL_NHANVIEN();
                if (XuLyDangNhap.DangNhap(taikhoan, matkhau))
                {
                    nv = new BEL_NHANVIEN(XuLyDangNhap.GetNV(taikhoan));
                    if (nv.TrangThai == 1)
                    {
                        if (nv.LoaiNV == 0)
                        {
                            this.Visible = false;
                            nhanvien = new BEL_NHANVIEN(nv);
                            Admin ad = new Admin();
                            ad.ShowDialog();
                            this.Close();
                        }
                        else if (nv.LoaiNV == 1)
                        {
                            this.Visible = false;
                            nhanvien = new BEL_NHANVIEN(nv);
                            BanHang BanHang = new BanHang();
                            BanHang.ShowDialog();
                            this.Close();
                        }
                        else if (nv.LoaiNV == 2)
                        {
                            this.Visible = false;
                            nhanvien = new BEL_NHANVIEN(nv);
                            ThuKho ThuKho = new ThuKho();
                            ThuKho.ShowDialog();
                            this.Close();
                        }            
                    }
                    else
                    {
                        MessageBox.Show("Tài khoản đã bị vô hiệu hóa !", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    txtPassWord.Text = "";
                    txtUserName.Text = "";
                    txtUserName.Focus();
                    MessageBox.Show("Đăng nhập thất bại !", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch(Exception err)
            {
                throw;
            }
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin_Click(sender, e);
            }
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            DialogResult kq = MessageBox.Show("Bạn chắc chắn muốn thoát?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(kq==DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}