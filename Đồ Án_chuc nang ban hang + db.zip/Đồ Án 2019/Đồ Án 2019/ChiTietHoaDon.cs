﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BAL;
using BEL;

namespace Đồ_Án_2019
{
    public partial class ChiTietHoaDon : Form
    {
        public ChiTietHoaDon()
        {
            InitializeComponent();
        }

        private void ChiTietHoaDon_Load(object sender, EventArgs e)
        {
            HienCTSP(dgvCTHD);
        }

        public void HienCTSP(DataGridView dgv)
        {
            BAL_CHITIETHOADON cthd = new BAL_CHITIETHOADON();

            string mahd = Admin.MaHDHT;
            dgv.DataSource = cthd.LoadCTHD(mahd);
        }
        private void btnInLai_Click(object sender, EventArgs e)
        {
            InHoaDonCu inhd = new InHoaDonCu();
            inhd.ShowDialog();
        }
    }
}
