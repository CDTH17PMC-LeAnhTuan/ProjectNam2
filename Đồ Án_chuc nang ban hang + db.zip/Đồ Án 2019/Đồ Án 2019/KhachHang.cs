﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BAL;
using System.Data.SqlClient;
using BEL;
namespace Đồ_Án_2019
{
    public partial class KhachHang : Form
    {
        public KhachHang()
        {
            InitializeComponent();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            BAL_KHACHHANG xuly = new BAL_KHACHHANG();
            DataTable kq= xuly.GetThongTin(comboBox1.Text);
            if (kq.Rows[0][2].Equals("nam"))
            {
                radNam.Checked = true;
            }
            else
            {
                radNu.Checked = true;
            }
            txtDiaChi.Text = kq.Rows[0][4].ToString();
            dateTimePicker1.Value = DateTime.Parse(kq.Rows[0][6].ToString());
        }
        private void KhachHang_Load(object sender, EventArgs e)
        {
            HienThi();
        }
        public void HienThi()
        {
            BAL_KHACHHANG xuly = new BAL_KHACHHANG();
            DataTable kq= xuly.GetDSKH();
            comboBox1.DisplayMember = "HoTen";
            comboBox1.DataSource = kq;
            comboBox2.DisplayMember = "SDT";
            comboBox2.DataSource = kq;
            if(kq.Rows[0][2].Equals("nam"))
            {
                radNam.Checked=true;
            }
            else
            {
                radNu.Checked=true;
            }
            txtDiaChi.Text=kq.Rows[0][4].ToString();
            dateTimePicker1.Value = DateTime.Parse(kq.Rows[0][6].ToString());
        }
        public static string MaKH = "";
        public static int LoaiKh = -1;
        public static bool trangthai = false;
        private void butOK_Click(object sender, EventArgs e)
        {
            BAL_KHACHHANG xuly = new BAL_KHACHHANG();
            if(xuly.KTTonTai(comboBox2.Text))
            {
                MaKH = xuly.GetThongTin(comboBox1.Text).Rows[0][0].ToString();
                LoaiKh = int.Parse(xuly.GetThongTin(comboBox1.Text).Rows[0][5].ToString());
                trangthai = true;
                this.Close();
            }
            else
            {
                BAL_KHACHHANG xulyMa = new BAL_KHACHHANG();
                string gioitinh="";
                if(radNam.Checked==true)
                {
                    gioitinh="nam";
                }
                else
                {
                    gioitinh="nữ";
                }
                DateTime ngaysinh=dateTimePicker1.Value;
                string ma=xulyMa.MaKHMoi();
                BEL_KHACHHANG kh = new BEL_KHACHHANG(ma, comboBox1.Text, gioitinh, comboBox2.Text, txtDiaChi.Text, 0,ngaysinh);
                BAL_KHACHHANG themKH = new BAL_KHACHHANG();
                themKH.AddKH(kh);
                MaKH = ma;
                LoaiKh = 0;
                trangthai = true;
                this.Close();
            }
        }
    }
}
