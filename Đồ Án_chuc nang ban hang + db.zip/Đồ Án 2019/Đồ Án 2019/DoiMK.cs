﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Đồ_Án_2019
{
    public partial class DoiMK : Form
    {
        public DoiMK()
        {
            InitializeComponent();
        }
        public static bool kq = false;

        private void btnOK_Click(object sender, EventArgs e)
        {
            if(txtMK.Text.Equals(Admin.mkmoi))
            {
                kq = true;
            }
            this.Close();
        }
    }
}
