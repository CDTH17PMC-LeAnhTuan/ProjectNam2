﻿namespace Đồ_Án_2019 {
    
    
    public partial class dsHoaDon {
    }
}

namespace Đồ_Án_2019.dsHoaDonTableAdapters {
    
    
    public partial class V_ChiTietHoaDon_SanPhamTableAdapter {
    }
}
