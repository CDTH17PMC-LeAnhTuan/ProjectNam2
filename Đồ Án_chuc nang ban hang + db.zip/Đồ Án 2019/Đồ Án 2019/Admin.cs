﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BAL;
using BEL;
using System.IO;
namespace Đồ_Án_2019
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }
        private void Admin_Load(object sender, EventArgs e)
        {
            HienThi();
        }
       // public static string MK = Form1.nhanvien.MatKhau;
        public void HienThi()
        {
            BAL_HOADON loadHD = new BAL_HOADON();
            DataTable hd = loadHD.GetDSHD();
            dataGridView2.DataSource = hd;
            BAL_NHANVIEN loadNV = new BAL_NHANVIEN();
            DataTable nv = loadNV.GetDSNV();
            dataGridView1.DataSource = nv;
            BAL_KHACHHANG loadKH = new BAL_KHACHHANG();
            DataTable kh = loadKH.GetDSKH();
            dgvDSKH.DataSource = kh;
            BAL_LOAISANPHAM loadLoaiSP = new BAL_LOAISANPHAM();
            comboBox1.DisplayMember = "TenLoai";
            comboBox1.DataSource = loadLoaiSP.GetDSTenLoaiSP();
            cboTenMaLoai.DisplayMember = "TenLoai";
            cboTenMaLoai.DataSource = loadLoaiSP.GetDSTenLoaiSP();
            BAL_SANPHAM load = new BAL_SANPHAM();
            DataTable kq = load.GetDSSP();
            dgvDSSanPham.DataSource = kq;
            comboBox2.DisplayMember = "TenSP";
            comboBox2.DataSource = load.GetDSTenSP(comboBox1.Text);
            DataTable kq2 = load.GetTien(comboBox2.Text);
            textBox1.Text = kq2.Rows[0][0].ToString();
            lblName.Text = Form1.nhanvien.MaNV;
            lblTaiKhoan.Text = Form1.nhanvien.TaiKhoan;
            lblNhanVien.Text = Form1.nhanvien.LoaiNV.ToString();
            lblLuong.Text = Form1.nhanvien.Luong.ToString();
            if (Form1.nhanvien.GioiTinh.Equals("nam"))
            {
                radNVNam.Checked = true;
            }
            else
            {
                radNVNu.Checked = true;
            }
            txtNVMauKhau.Text = Form1.nhanvien.MatKhau;
            txtNVTen.Text = Form1.nhanvien.TenVN;
            string currentPath = Directory.GetCurrentDirectory();
            string Path = @"\img\NhanVien\";
            currentPath = currentPath + Path + Form1.nhanvien.MaNV.Trim() + ".jpg";
            pictureBox2.ImageLocation = currentPath;
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            BAL_SANPHAM load = new BAL_SANPHAM();
            DataTable kq2 = load.GetTien(comboBox2.Text);
            textBox1.Text = kq2.Rows[0][0].ToString();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            BAL_SANPHAM load = new BAL_SANPHAM();
            DataTable kq = load.GetDSSP();
            dgvDSSanPham.DataSource = kq;
            comboBox2.DisplayMember = "TenSP";
            comboBox2.DataSource = load.GetDSTenSP(comboBox1.Text);
            DataTable kq2 = load.GetTien(comboBox2.Text);
            textBox1.Text = kq2.Rows[0][0].ToString();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult Logout = MessageBox.Show("Bạn có chắc chắn muốn đăng xuất", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Logout == DialogResult.Yes)
            {
                this.Visible = false;
                Form1.nhanvien = new BEL_NHANVIEN();
                Form1 frm1 = new Form1();
                frm1.ShowDialog();
                this.Close();
            }
        }
        private void dgvDSSanPham_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string masp = dgvDSSanPham.CurrentRow.Cells[0].Value.ToString();
            BAL_SANPHAM xylysp = new BAL_SANPHAM();
            DataTable dt = new DataTable();
            dt = xylysp.GetSP(masp);
            txtMaSP.Text = dt.Rows[0]["MaSP"].ToString();
            txtTenSP.Text = dt.Rows[0]["TenSP"].ToString();
            txtGiaSP.Text = dt.Rows[0]["GiaThanh"].ToString();
            txtSoLuong.Text = dt.Rows[0]["SoLuong"].ToString();
            BAL_LOAISANPHAM loadLoaiSP = new BAL_LOAISANPHAM();
            cboTenMaLoai.DisplayMember = "TenLoai";
            cboTenMaLoai.DataSource = loadLoaiSP.GetDSTenLoaiSP();
            cboTenMaLoai.Text = loadLoaiSP.GetDSTenLoaiSP(dt.Rows[0]["MaLoai"].ToString()).Rows[0][0].ToString();
        }
        private void btnXoa_Click(object sender, EventArgs e)
        {
            txtMaSP.Text = "";
            txtTenSP.Text = "";
            txtGiaSP.Text = "";
            txtSoLuong.Text = "";
        }
        private void btnThem_Click(object sender, EventArgs e)
        {
            string tensp = txtTenSP.Text.ToUpper();
            BAL_SANPHAM xuly = new BAL_SANPHAM();
            BAL_LOAISANPHAM xulyloaisp = new BAL_LOAISANPHAM();
            if (!xuly.KTTonTai(tensp))
            {
                BEL_SANPHAM sp = new BEL_SANPHAM();
                string masp = "SP" + xuly.MaSPMoi();
                int sl = int.Parse(txtSoLuong.Text);
                float gia = float.Parse(txtGiaSP.Text);
                string maloai = xulyloaisp.GetMaLoai(cboTenMaLoai.Text);
                sp.MaSP = masp;
                sp.TenSP = tensp;
                sp.MaLoai = maloai.Trim();
                sp.SoLuong = sl;
                sp.GiaThanh = gia;
                MessageBox.Show(sp.MaSP + sp.TenSP + sp.MaLoai + sp.SoLuong + sp.GiaThanh);
                if (xuly.AddSP(sp))
                {
                    HienThi();
                }
                else
                {
                    MessageBox.Show("Thêm sản phẩm thất bại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.None);
                }
            }
            else
            {
                MessageBox.Show("Sản phẩm đã tồn tại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        public static string mkmoi = "";
        private void btnCapNhatNV_Click(object sender, EventArgs e)
        {
            mkmoi = txtNVMauKhau.Text;
            string GioiTinh = "";
            if (radNVNam.Checked)
            {
                GioiTinh = "nam";
            }
            else
            {
                GioiTinh = "nữ";
            }
            BAL_NHANVIEN xulyUpdate = new BAL_NHANVIEN();
            if (!txtNVMauKhau.Text.Equals(Form1.nhanvien.MatKhau))
            {
                DoiMK fmr = new DoiMK();
                fmr.ShowDialog();
                if (DoiMK.kq == true)
                {
                    xulyUpdate.UpdateNV(Form1.nhanvien.MaNV, txtNVTen.Text, GioiTinh, txtNVMauKhau.Text);
                    DoiMK.kq = false;
                    Form1.nhanvien = new BEL_NHANVIEN((xulyUpdate.GetNV(Form1.nhanvien.TaiKhoan)));
                    HienThi();
                    MessageBox.Show("Cập Nhật Thành Công");
                }
                else
                {
                    HienThi();
                    MessageBox.Show("Nhập Mật Khẩu Sai");
                }
            }
            else
            {
                xulyUpdate.UpdateNV(Form1.nhanvien.MaNV, txtNVTen.Text, GioiTinh, txtNVMauKhau.Text);
                Form1.nhanvien = new BEL_NHANVIEN((xulyUpdate.GetNV(Form1.nhanvien.TaiKhoan)));
                HienThi();
                MessageBox.Show("Cập Nhật Thành Công");
            }
        }
        private void btnChiTietHD_Click(object sender, EventArgs e)
        {
            MaHDHT = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            ChiTietHoaDon cthd = new ChiTietHoaDon();
            cthd.ShowDialog();
        }
        public static string MaHDHT = "";
        public List<BEL_CHITIETHOADON> GioHang = new List<BEL_CHITIETHOADON>();//tạo ra list để có thể lưu các sản phẩm trong giỏ hàng để tí có thể thanh toán
        private void btnThemhang_Click(object sender, EventArgs e)//thêm 1 sản phẩm vào giỏ hàng
        {
            BAL_SANPHAM xulyTenSP=new BAL_SANPHAM();
            bool t = true;//biến cờ để xem sản phẩm đã có trong giỏ hàng chưa
            int index=-1;//tạo biến vị trí của sản phẩm nếu đã tồn tại trong giỏ hàng
            for(int i=0;i<GioHang.Count;i++)//kiểm tra sản phẩm mới thêm vào đã có trong giỏ hàng chưa
            {
                if(GioHang[i].MaSP.Equals(xulyTenSP.LayMaSP(comboBox2.Text)))
                {
                    t = false;
                    index=i;//lấy vị trí sản phẩm trùng
                }
            }
            if(t==true)//nếu sản phẩm ko trùng thì chạy các câu lệnh thêm vào giỏ hàng
            {
                BAL_HOADON xulyHoaDon = new BAL_HOADON();
                string mahd = xulyHoaDon.GetTenMoiNhat();//lấy mã hóa đơn mới nhất
                BAL_SANPHAM xyluSanPham = new BAL_SANPHAM();
                string masp = xyluSanPham.LayMaSP(comboBox2.Text);
                if (xulyTenSP.KTSoLuong(int.Parse(textBox2.Text), comboBox2.Text) == true)//kiểm tra số lượng sản phẩm còn đủ để bán ko
                {
                    int tien = int.Parse(textBox2.Text) * int.Parse(textBox1.Text);
                    BEL_CHITIETHOADON temp = new BEL_CHITIETHOADON(mahd, masp, int.Parse(textBox2.Text), tien);//tạo ra 1 BEL_CHITIETHOADON để lưu vào giỏ hàng
                    dgvGioHang.Rows.Add(comboBox2.Text, tien, textBox2.Text);
                    GioHang.Add(temp);
                }
                else//nếu ko đủ sản phẩm
                {
                    MessageBox.Show("Không đủ hàng cho sản phẩm " + comboBox2.Text);  
                }
            }
            else//nếu sản phẩm đã tồn tại trong giỏ hàng thì hỏi có update lại số lượng hay ko
            {
                DialogResult kq = MessageBox.Show("Đã tồn tại sản phẩm này trong giỏ hàng bạn muốn cập nhật lại chứ ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(kq==DialogResult.Yes)
                {
                    GioHang.RemoveAt(index);//xóa khỏi list,index lấy ở trên
                    dgvGioHang.Rows.RemoveAt(index);//xóa trên giao diện
                    btnThemhang_Click(sender, e);//thêm lại với số lượng mới
                }
            }
        }
        private void btnCapNhat1_Click(object sender, EventArgs e)//giống như xử lý sản phẩm đã tồn tại trong giỏ hàng
        {
            BAL_SANPHAM xulyTenSP = new BAL_SANPHAM();
            int index = -1;
            for (int i = 0; i < GioHang.Count; i++)
            {
                if (GioHang[i].MaSP.Equals(xulyTenSP.LayMaSP(comboBox2.Text)))
                {
                    index = i;
                }
            }
            GioHang.RemoveAt(index);
            dgvGioHang.Rows.RemoveAt(index);
            btnThemhang_Click(sender, e);
        }
        private void dgvGioHang_CellClick(object sender, DataGridViewCellEventArgs e)//click vào sản phẩm trên giỏ hàng hiển thị lại lên giao diện
        {
            BAL_LOAISANPHAM xulyLoai = new BAL_LOAISANPHAM();
            comboBox1.Text = xulyLoai.GetTenLoaiTheoTenSP(dgvGioHang.CurrentRow.Cells[0].Value.ToString());
            comboBox2.Text = dgvGioHang.CurrentRow.Cells[0].Value.ToString();
            BAL_SANPHAM xulytien = new BAL_SANPHAM();
            textBox1.Text = xulytien.GetTien(dgvGioHang.CurrentRow.Cells[0].Value.ToString()).Rows[0][0].ToString();
            textBox2.Text = dgvGioHang.CurrentRow.Cells[2].Value.ToString();
        }
        private void btnXoa1_Click(object sender, EventArgs e)//xóa sản phẩm đang chọn trong giỏ hàng(chưa bắt ko chọn sẽ báo hãy chọn)
        {
            GioHang.RemoveAt(dgvGioHang.CurrentRow.Index);
            dgvGioHang.Rows.RemoveAt(dgvGioHang.CurrentRow.Index);
        }
        private void btnTaoHD_Click(object sender, EventArgs e)//nút thanh toán
        {
            if(GioHang.Count==0)//nếu giỏ hàng trống
            {
                MessageBox.Show("chưa có sản phẩm nào trong giỏ hàng");
            }
            else//nếu có sản phẩm trong giỏ hàng
            {
                KhachHang kh = new KhachHang();//mở form khách hàng, để có thể lấy mã khách hàng, và trạng thái vip thường của khách hàng đó hoặc tạo mới 1 khách hàng
                kh.ShowDialog();
                if(KhachHang.trangthai==true)
                {
                    BAL_HOADON xulyHoaDon = new BAL_HOADON();
                    string mahd = xulyHoaDon.GetTenMoiNhat();//tạo MaHD mới
                    BAL_CHITIETHOADON xlyGioHang = new BAL_CHITIETHOADON();
                    float TongTien = 0;
                    for (int i = 0; i < GioHang.Count; i++)//tính tổng tiền của 1 hóa đơn(duyệt hết giỏ hàng)
                    {
                        if (KhachHang.LoaiKh == 1)//khuyến mãi giảm 10% cho các khác hàng vip
                        {
                            GioHang[i].SoTien = GioHang[i].SoTien * 90 / 100;
                        }
                        TongTien += GioHang[i].SoTien;
                    }
                    BEL_HOADON hd = new BEL_HOADON(mahd.Trim(), KhachHang.MaKH, Form1.nhanvien, TongTien);//tạo 1 BEL_HOADON để tí có thể add vào database
                    if (xulyHoaDon.AddHD(hd))//nếu thêm hóa đơn thành công thì bắt đầu thêm các chi tiết hóa đơn vào
                    {
                        BAL_SANPHAM xulysp = new BAL_SANPHAM();
                        for (int i = 0; i < GioHang.Count; i++)//duyệt list giỏ hàng để thêm vào database
                        {
                            if (xlyGioHang.addChiTietHoaDon(GioHang[i]))
                            {
                                xulysp.updateSL(GioHang[i]);//trừ số lượng sản phẩm đã bán
                            }
                        }
                        if (KhachHang.LoaiKh == 1)//xuất thông báo nếu là khách hàng vip
                        {
                            MessageBox.Show("Hoa Don Da Duoc Giam 10%");
                            InHoaDon inhd = new InHoaDon();
                            inhd.ShowDialog();
                        }
                        else
                        {
                            InHoaDon inhd = new InHoaDon();
                            inhd.ShowDialog();
                            BAL_KHACHHANG xulyKH = new BAL_KHACHHANG();
                            if (xulyKH.UpdateKH(KhachHang.MaKH))
                            {
                                MessageBox.Show("Khach hang " + KhachHang.MaKH + " da thanh khach hang than thiet");
                            }
                        }

                        for (int i = 0; i < GioHang.Count; i++)//xóa giỏ hàng trên giao diện
                        {
                            dgvGioHang.Rows.RemoveAt(i);
                        }
                        GioHang.Clear();//xóa giỏ hàng trong list
                        HienThi();
                    }
                    else
                    {
                        MessageBox.Show("thanh toan that bai");
                    }
                }
                else
                {
                    MessageBox.Show("lấy thông tin khách hàng lỗi");
                }
            }
        }
    }
}
