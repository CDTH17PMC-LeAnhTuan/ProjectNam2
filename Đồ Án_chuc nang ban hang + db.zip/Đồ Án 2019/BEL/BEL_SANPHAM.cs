﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace BEL
{
    public class BEL_SANPHAM
    {
        private String _MaSP;
        private String _TenSP;
        private int _SoLuong;
        private float _GiaThanh;
        private String _MaLoai;
        public String MaSP
        {
            get { return _MaSP; }
            set { _MaSP = value; }
        }
        public String TenSP
        {
            get { return _TenSP; }
            set { _TenSP = value; }
        }
        public int SoLuong
        {
            get { return _SoLuong; }
            set { _SoLuong = value; }
        }
        public float GiaThanh
        {
            get { return _GiaThanh; }
            set { _GiaThanh = value; }
        }
        public String MaLoai
        {
            get { return _MaLoai; }
            set { _MaLoai = value; }
        }
    }
}
