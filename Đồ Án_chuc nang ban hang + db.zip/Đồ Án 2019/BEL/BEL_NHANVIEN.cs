﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace BEL
{
    public class BEL_NHANVIEN
    {
        private String _MaNV;
        private String _TenNV;
        private String _GioiTinh;
        private String _TaiKhoan;
        private String _MatKhau;
        private int _LoaiNV;
        private int _Luong;
        private int _TrangThai;
        public String MaNV
        {
            get { return _MaNV; }
            set { _MaNV = value; }
        }
        public String TenVN
        {
            get { return _TenNV; }
            set { _TenNV = value; }
        }
        public String GioiTinh
        {
            get { return _GioiTinh; }
            set { _GioiTinh = value; }
        }
        public String TaiKhoan
        {
            get { return _TaiKhoan; }
            set { _TaiKhoan = value; }
        }
        public String MatKhau
        {
            get { return _MatKhau; }
            set { _MatKhau = value; }
        }
        public int LoaiNV
        {
            get { return _LoaiNV; }
            set { _LoaiNV = value; }
        }
        public int Luong
        {
            get { return _Luong; }
            set { _Luong = value; }
        }
        public int TrangThai
        {
            get { return _TrangThai; }
            set { _TrangThai = value; }
        }
        public BEL_NHANVIEN ()
        {
            _MaNV = "temp";
        }
        public BEL_NHANVIEN (DataTable dt)
        {
            _MaNV = dt.Rows[0][0].ToString() ;
            _TenNV = dt.Rows[0][1].ToString();
            _GioiTinh = dt.Rows[0][2].ToString();
            _TaiKhoan = dt.Rows[0][3].ToString();
            _MatKhau = dt.Rows[0][4].ToString();
            _LoaiNV = int.Parse(dt.Rows[0][5].ToString());
            _Luong = int.Parse(dt.Rows[0][6].ToString());
            _TrangThai = int.Parse(dt.Rows[0][7].ToString());
        }
        public BEL_NHANVIEN(BEL_NHANVIEN nv)
        {
            _MaNV = nv.MaNV;
            _TenNV = nv.TenVN;
            _GioiTinh = nv.GioiTinh;
            _TaiKhoan = nv.TaiKhoan;
            _MatKhau = nv.MatKhau;
            _LoaiNV = nv.LoaiNV;
            _Luong = nv.Luong;
            _TrangThai = nv.TrangThai;
        }
    }
}
