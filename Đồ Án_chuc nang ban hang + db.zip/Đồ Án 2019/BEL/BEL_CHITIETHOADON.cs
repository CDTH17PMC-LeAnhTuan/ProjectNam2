﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace BEL
{
    public class BEL_CHITIETHOADON
    {
        private string _MaHD;

        public string MaHD
        {
            get { return _MaHD; }
            set { _MaHD = value; }
        }
        private string _MaSP;

        public string MaSP
        {
            get { return _MaSP; }
            set { _MaSP = value; }
        }
        private int _SLSanPham;

        public int SLSanPham
        {
            get { return _SLSanPham; }
            set { _SLSanPham = value; }
        }
        private float _SoTien;

        public float SoTien
        {
            get { return _SoTien; }
            set { _SoTien = value; }
        }

        public BEL_CHITIETHOADON()
        {
            _MaHD = "temp";
        }
        public BEL_CHITIETHOADON(string mahd, string masp, int slsp, float tien)
        {
            _MaHD = mahd;
            _MaSP = masp;
            _SLSanPham = slsp;
            _SoTien = tien;
        }
    }
}
