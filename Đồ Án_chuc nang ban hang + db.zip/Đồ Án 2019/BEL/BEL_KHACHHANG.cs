﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace BEL
{
    
    public class BEL_KHACHHANG
    {
        private string _MaKH;

        public string MaKH
        {
            get { return _MaKH; }
            set { _MaKH = value; }
        }
        private string _Hoten;

        public string Hoten
        {
            get { return _Hoten; }
            set { _Hoten = value; }
        }
        private string _GioiTinh;

        public string GioiTinh
        {
            get { return _GioiTinh; }
            set { _GioiTinh = value; }
        }
        private string _SDT;

        public string SDT
        {
            get { return _SDT; }
            set { _SDT = value; }
        }
        private string _DiaChi;

        public string DiaChi
        {
            get { return _DiaChi; }
            set { _DiaChi = value; }
        }
        private int _MaLoaiKH;

        public int MaLoaiKH
        {
            get { return _MaLoaiKH; }
            set { _MaLoaiKH = value; }
        }
        private DateTime _NgaySinh;

        public DateTime NgaySinh
        {
            get { return _NgaySinh; }
            set { _NgaySinh = value; }
        }

        public BEL_KHACHHANG()
        {
            MaKH = "";
        }

        public BEL_KHACHHANG(string makh,string hoten,string gioitinh,string sdt,string diachi,int maloaikh,DateTime ngaysinh)
        {
            MaKH = makh;
            Hoten = hoten;
            GioiTinh = gioitinh;
            SDT = sdt;
            DiaChi = diachi;
            MaLoaiKH = maloaikh;
            NgaySinh = ngaysinh;
        }
    }
}
