﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace BEL
{
    public class BEL_HOADON
    {
        private string _MaHD;

        public string MaHD
        {
            get { return _MaHD; }
            set { _MaHD = value; }
        }
        private string _MaKH;

        public string MaKH
        {
            get { return _MaKH; }
            set { _MaKH = value; }
        }
        private string _MaNV;

        public string MaNV
        {
            get { return _MaNV; }
            set { _MaNV = value; }
        }
        private float _TongTien;

        public float TongTien
        {
            get { return _TongTien; }
            set { _TongTien = value; }
        }
        private DateTime _NgayLap;

        public DateTime NgayLap
        {
            get { return _NgayLap; }
            set { _NgayLap = value; }
        }

        public BEL_HOADON()
        {
            _MaHD = "temp";
        }
        public BEL_HOADON(string mahd,string makh,BEL_NHANVIEN nv,float tongtien)
        {
            _MaHD = mahd;
            _MaKH = makh;
            _MaNV = nv.MaNV;
            _TongTien = tongtien;
            _NgayLap = DateTime.Now;
        }
    }
}
