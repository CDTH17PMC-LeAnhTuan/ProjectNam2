﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BEL;
using DAL;
using System.Data;
using System.Data.SqlClient;

namespace BAL
{
    public class BAL_LOAISANPHAM
    {
        public DataTable GetDSTenLoaiSP()
        {
            DAL_LOAISANPHAM DoiTuong = new DAL_LOAISANPHAM();
            return DoiTuong.LoadTenLoaiSP();
        }
        public DataTable GetDSTenLoaiSP(string maloai)
        {
            DAL_LOAISANPHAM DoiTuong = new DAL_LOAISANPHAM();
            return DoiTuong.LoadTenLoaiSP(maloai);
        }
        public string GetMaLoai(string tenloai)
        {
            DAL_LOAISANPHAM DoiTuong = new DAL_LOAISANPHAM();
            return DoiTuong.GetMaLoai(tenloai);
        }
        public string GetTenLoaiTheoTenSP(string tensp)
        {
            DAL_LOAISANPHAM DoiTuong= new DAL_LOAISANPHAM();
            return DoiTuong.GetTenLoaiTheoTenSP(tensp);
        }
    }
}
