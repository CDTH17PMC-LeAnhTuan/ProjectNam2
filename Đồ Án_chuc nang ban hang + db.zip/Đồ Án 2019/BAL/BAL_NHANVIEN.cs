﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BEL;
namespace BAL
{
    public class BAL_NHANVIEN
    {
        public bool DangNhap(string taikhoan, string matkhau)
        {
            try
            {
                DAL_NHANVIEN objdal = new DAL_NHANVIEN();
                return objdal.DangNhap(taikhoan, matkhau);
            }
            catch 
            {
                throw;
            }
        }
        public DataTable GetNV(string taikhoan)
        {
            try
            {
                DAL_NHANVIEN objdal = new DAL_NHANVIEN();
                return objdal.LoadNV(taikhoan);
            }
            catch
            {
                throw;
            }
        }
        public DataTable GetDSNV()
        {
            DAL_NHANVIEN DoiTuong = new DAL_NHANVIEN();
            return DoiTuong.LoadDSNV();
        }
        public void UpdateNV(string MaNV, string Ten, string GioiTinh, string matkhau)
        {
            DAL_NHANVIEN DoiTuong = new DAL_NHANVIEN();
            DoiTuong.UpdateNV(MaNV, Ten, GioiTinh, matkhau);
        }
    }
}
