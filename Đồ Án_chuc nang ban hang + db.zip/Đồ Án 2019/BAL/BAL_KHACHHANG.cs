﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BEL;
namespace BAL
{
    public class BAL_KHACHHANG
    {
        public DataTable GetDSKH()
        {
            DAL_KHACHHANG DoiTuong = new DAL_KHACHHANG();
            return DoiTuong.LoadKH();
        }
        public DataTable GetThongTin(string tenkh)
        {
            DAL_KHACHHANG DoiTuong = new DAL_KHACHHANG();
            return DoiTuong.LoadKH(tenkh);
        }
        public bool KTTonTai(string sdt)
        {
            DAL_KHACHHANG DoiTuong = new DAL_KHACHHANG();
            return DoiTuong.KTTonTaiKH(sdt);
        }
        public string MaKHMoi()
        {
            DAL_KHACHHANG DoiTuong = new DAL_KHACHHANG();
            return DoiTuong.MaKHMoi();
        }
        public bool AddKH(BEL_KHACHHANG kh)
        {
            DAL_KHACHHANG DoiTuong = new DAL_KHACHHANG();
            return DoiTuong.AddKH(kh);
        }
        public bool UpdateKH(string makh)
        {
            DAL_KHACHHANG DoiTuong = new DAL_KHACHHANG();
            return DoiTuong.UpdateKH(makh);
        }
    }
}
