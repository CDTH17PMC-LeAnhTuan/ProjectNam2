﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using System.Data;
using System.Data.SqlClient;
using BEL;
namespace BAL
{
    public class BAL_HOADON
    {
        public DataTable GetDSHD()
        {
            DAL_HOADON DoiTuong = new DAL_HOADON();
            return DoiTuong.LoadHD();
        }
        public String GetTenMoiNhat()
        {
            DAL_HOADON DoiTuong = new DAL_HOADON();
            return DoiTuong.LoadTenMoiNhat();
        }
        public bool AddHD(BEL_HOADON hd)
        {
            DAL_HOADON DoiTuong = new DAL_HOADON();
            return DoiTuong.AddHD(hd);
        }
    }
}
