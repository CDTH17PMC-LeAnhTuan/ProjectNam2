﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BEL;
using DAL;
using System.Data;
using System.Data.SqlClient;

namespace BAL
{
    public class BAL_SANPHAM
    {
        public DataTable GetDSSP()
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.LoadSP();
        }
        public DataTable GetDSTenSP()
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.LoadTenSP();
        }
        public DataTable GetDSTenSP(string loaisp)
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.LoadTenSP(loaisp);
        }
        public DataTable GetSP(string masp)
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.LoadSP(masp);
        }
        public DataTable GetTien(String sp)
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.LoadSoTien(sp);
        }
        public bool KTTonTai(string tensp)
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.KTTonTai(tensp);
        }
        public int MaSPMoi()
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.MaSPMoi();
        }
        
        public bool AddSP(BEL_SANPHAM sp)
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.AddSP(sp);
        }
        public string LayMaSP(string TenSp)
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.MaSPTheoTenSP(TenSp);
        }
        public string LayTenSP(string MaSp)
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.TenSPTheoMaSP(MaSp);
        }
        public bool KTSoLuong(int SL,string ten)
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.KTSoLuong(SL,ten);
        }
        public bool updateSL(BEL_CHITIETHOADON cthd)
        {
            DAL_SANPHAM DoiTuong = new DAL_SANPHAM();
            return DoiTuong.updateSL(cthd);
        }
    }
}
