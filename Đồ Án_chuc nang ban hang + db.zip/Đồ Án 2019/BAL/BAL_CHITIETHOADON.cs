﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using System.Data;
using System.Data.SqlClient;
using BEL;
namespace BAL
{
    public class BAL_CHITIETHOADON
    {
        public DataTable LoadCTHD(string mahd)
        {
            DAL_CHITIETHOADON obj = new DAL_CHITIETHOADON();
            return obj.LoadCTHD(mahd);
        }
        public bool addChiTietHoaDon(BEL_CHITIETHOADON cthd)
        {
            DAL_CHITIETHOADON DoiTuong = new DAL_CHITIETHOADON();
            return DoiTuong.addChiTietHoaDon(cthd);
        }
    }
}
