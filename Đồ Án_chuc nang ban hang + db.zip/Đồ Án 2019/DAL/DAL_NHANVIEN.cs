﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BEL;
namespace DAL
{
    public class DAL_NHANVIEN:General
    {
        public bool DangNhap(string taikhoan, string matkhau)
        {
            object kq;
            try
            {
                getConnect();
                SqlCommand sql = new SqlCommand("select TaiKhoan,MatKhau from NHANVIEN where TaiKhoan='" + taikhoan + "' and MatKhau='" + matkhau + "'", conn);
                kq = sql.ExecuteScalar();
                return kq != null;
            }
            catch 
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
        }
        public DataTable LoadDSNV()
        {
            getConnect();
            SqlCommand command = new SqlCommand("select MaNV,TenNV,GioiTinh,LoaiNV,Luong,TrangThai from NhanVien,LoaiNhanVien,TrangThai where NhanVien.MaLoaiNV=LoaiNhanVien.MaLoaiNV and NhanVien.MaTrangThai=TrangThai.MaTrangThai", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        }
        public DataTable LoadNV(string taikhoan)
        {
            try
            {
                getConnect();
                SqlCommand sql = new SqlCommand("select * from NHANVIEN where TaiKhoan='"+ taikhoan+"'", conn);
                SqlDataReader rd = sql.ExecuteReader();
                dt.Load(rd);
                return dt;
            }

            catch 
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
        }
        public void UpdateNV(string MaNV,string Ten,string GioiTinh,string matkhau)
        {
            getConnect();
            SqlCommand sql = new SqlCommand("update NhanVien set MatKhau='" + matkhau + "',GioiTinh=N'" + GioiTinh + "',TenNV=N'" + Ten + "' where MaNV='"+MaNV+"' ", conn);
            try
            {
                sql.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }
        }
    }
}
