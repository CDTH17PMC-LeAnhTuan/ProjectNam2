﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BEL;
namespace DAL
{
    public class DAL_SANPHAM : General
    {
        public DataTable LoadSP()
        {
            getConnect();
            SqlCommand command = new SqlCommand("select MaSP, TenSP, SoLuong, GiaThanh, TenLoai from SanPham,LoaiSanPham where SanPham.MaLoai=LoaiSanPham.MaLoai", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        }

        public DataTable LoadTenSP()
        {
            getConnect();
            SqlCommand command = new SqlCommand("select TenSP from SanPham", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        }

        public DataTable LoadTenSP(string loaisp)
        {
            getConnect();
            SqlCommand command = new SqlCommand("select TenSP from SanPham, LoaiSanPham where SanPham.MaLoai=LoaiSanPham.MaLoai and LoaiSanPham.TenLoai like N'" + loaisp + "'", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        }
        public DataTable LoadSP(string masp)
        {
            getConnect();
            SqlCommand command = new SqlCommand("select MaSP,TenSP,SoLuong,GiaThanh,MaLoai from SanPham where MaSP like '" + masp + "'", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        }
        public DataTable LoadSoTien(String sp)
        {
            getConnect();
            SqlCommand command = new SqlCommand("select GiaThanh from SanPham where TenSP like '" + sp + "'", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        }
        public bool KTTonTai(string tensp)
        {

            object kq;
            try
            {
                getConnect();
                SqlCommand sql = new SqlCommand("select TenSP from SanPham where TenSP like N'" + tensp + "'", conn);
                kq = sql.ExecuteScalar();
                return kq != null;
            }
            catch
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
        }
        public int MaSPMoi()
        {
            getConnect();
            SqlCommand command = new SqlCommand("select count(MaSP) from SanPham", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return int.Parse(dt.Rows[0][0].ToString()) + 1;
        }

        public bool AddSP(BEL_SANPHAM sp)
        {
            bool kq = false;
            try
            {
                getConnect();
                string sql = string.Format("insert into SanPham values('{0}',N'{1}',{2},{3},'{4}')", sp.MaSP, sp.TenSP, sp.SoLuong, sp.GiaThanh, sp.MaLoai);
                SqlCommand cmd = new SqlCommand(sql, conn);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    kq = true;
                }
            }
            catch (Exception err)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return kq;
        }
        public string MaSPTheoTenSP(string TenSP)
        {
            getConnect();
            string sql = "select MaSP from SanPham where TenSP like N'" + TenSP + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader rd = cmd.ExecuteReader();
            dt.Load(rd);
            return dt.Rows[0][0].ToString();
        }
        public string TenSPTheoMaSP(string MaSP)
        {
            getConnect();
            string sql = "select TenSP from SanPham where MaSP like N'" + MaSP + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader rd = cmd.ExecuteReader();
            dt.Load(rd);
            return dt.Rows[0][0].ToString();
        }
        public bool KTSoLuong(int SL,string ten)
        {
            getConnect();
            string sql = "select SoLuong from SanPham where TenSP like N'" + ten + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader rd = cmd.ExecuteReader();
            dt.Load(rd);
            int sl = int.Parse(dt.Rows[0][0].ToString());
            if (SL <= sl)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool updateSL(BEL_CHITIETHOADON cthd)
        {
            getConnect();
            string sql = "update SanPham set SoLuong=SoLuong-" + cthd.SLSanPham + " where MaSP like '" + cthd.MaSP + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            if(cmd.ExecuteNonQuery()>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public string ChuyenDateThanhString(DateTime dt)
        {
            string m = dt.Month.ToString();
            string d = dt.DayOfYear.ToString();
            string y = dt.Year.ToString();
            string kq = m + "/" + d + "/" + y;
            return kq;
        }
    }
}
