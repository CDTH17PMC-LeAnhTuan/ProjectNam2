﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BEL;
namespace DAL
{
    public class DAL_CHITIETHOADON:General
    {
        public DataTable LoadCTHD(string mahd)
        {
            getConnect();
            SqlCommand command = new SqlCommand("select ChiTietHoaDon.MaHD, TenSP, SLSanPham, SoTien from ChiTietHoaDon, HoaDon, SanPham where HoaDon.MaHD = ChiTietHoaDon.MaHD and ChiTietHoaDon.MaSP = SanPham.MaSP and ChiTietHoaDon.MaHD = '"+mahd+"'", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        }
        public bool addChiTietHoaDon(BEL_CHITIETHOADON cthd)
        {
            getConnect();
            string query=string.Format("insert into ChiTietHoaDon values ('{0}','{1}',{2},{3})",cthd.MaHD,cthd.MaSP,cthd.SLSanPham,cthd.SoTien);
            SqlCommand command=new SqlCommand(query,conn);
            if(command.ExecuteNonQuery()>0)
            {
                return true;
            }
            return false;
        }
    }
}
