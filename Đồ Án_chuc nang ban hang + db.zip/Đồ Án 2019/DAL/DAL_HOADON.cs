﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BEL;
namespace DAL
{
    public class DAL_HOADON:General
    {
        public DataTable LoadHD()
        {
            getConnect();
            SqlCommand command = new SqlCommand("select * from HoaDon", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        }
        public string LoadTenMoiNhat()
        {
            getConnect();
            SqlCommand command = new SqlCommand("select count(*) from HoaDon", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            int k = int.Parse(dt.Rows[0][0].ToString())+1;
            return "HD" + k;
        }
        public bool AddHD(BEL_HOADON hd)
        {
            bool kq = false;
            try
            {
                getConnect();
                string sql = string.Format("insert into HoaDon values('{0}','{1}','{2}',{3},'{4}')",hd.MaHD, hd.MaKH, hd.MaNV, hd.TongTien, hd.NgayLap.ToString("MM/dd/yyyy"));
                SqlCommand cmd = new SqlCommand(sql, conn);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    kq = true;
                }
            }
            catch (Exception err)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return kq;
        }
        public float TongTienCuaKH(string makh)
        {
            getConnect();
            string sql = "select SUM(TongTien)from HoaDon where MaKH='" + makh + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader rd = cmd.ExecuteReader();
            dt.Load(rd);
            return float.Parse(dt.Rows[0][0].ToString());
        }
        public string ChuyenDateThanhString(DateTime dt)
        {
            string m = dt.Month.ToString();
            string d = dt.DayOfYear.ToString();
            string y = dt.Year.ToString();
            string kq = m + "/" + d + "/" + y;
            return kq;
        }
    }
}