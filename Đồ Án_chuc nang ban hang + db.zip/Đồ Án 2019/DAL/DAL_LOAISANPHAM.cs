﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BEL;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
    public class DAL_LOAISANPHAM:General
    {
        public DataTable LoadTenLoaiSP()
        {
            getConnect();
            SqlCommand command = new SqlCommand("select TenLoai from LoaiSanPham", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        }
        public DataTable LoadTenLoaiSP(string maloai)
        {
            getConnect();
            SqlCommand command = new SqlCommand("select TenLoai from LoaiSanPham where MaLoai like '"+maloai+"'", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        }
        public string GetMaLoai(string tenloai)
        {
            getConnect();
            SqlCommand command = new SqlCommand("select MaLoai from LoaiSanPham where TenLoai like N'"+tenloai+"'", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt.Rows[0][0].ToString();
        }
        public string GetTenLoaiTheoTenSP(string TenSP)
        {
            getConnect();
            SqlCommand command = new SqlCommand("select TenLoai from LoaiSanPham,SanPham where SanPham.MaLoai=LoaiSanPham.MaLoai and TenSP like N'" + TenSP + "'", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt.Rows[0][0].ToString();
        }
    }
}
