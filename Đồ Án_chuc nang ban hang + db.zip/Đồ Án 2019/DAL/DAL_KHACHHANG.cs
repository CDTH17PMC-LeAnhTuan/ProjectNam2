﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BEL;
namespace DAL
{
    public class DAL_KHACHHANG:General
    {
        public DataTable LoadKH()
        {
            getConnect();
            SqlCommand command = new SqlCommand("select * from KhachHang", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        }
        public DataTable LoadKH(string tenkh)
        {
            getConnect();
            SqlCommand command = new SqlCommand("select * from KhachHang where HoTen like N'"+tenkh+"'", conn);
            SqlDataReader rd = command.ExecuteReader();
            dt.Load(rd);
            return dt;
        } 
        public bool KTTonTaiKH(string sdt)
        {
            object kq;
            getConnect();
            SqlCommand sql = new SqlCommand("select * from KhachHang where SDT like '" + sdt + "'", conn);
            kq = sql.ExecuteScalar();
            return kq != null;
            
        }
        public bool AddKH(BEL_KHACHHANG kh)
        {
            bool kq = false;
            try
            {
                getConnect();
                string sql = string.Format("insert into KhachHang values('{0}',N'{1}',N'{2}','{3}',N'{4}',{5},'{6}')", kh.MaKH, kh.Hoten, kh.GioiTinh, kh.SDT, kh.DiaChi, kh.MaLoaiKH, kh.NgaySinh.ToString("MM/dd/yyyy"));
                SqlCommand cmd = new SqlCommand(sql, conn);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    kq = true;
                }
            }
            catch (Exception err)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return kq;
        }
        public bool UpdateKH(string makh)
        {
            getConnect();
            DAL_HOADON getTien=new DAL_HOADON();
            float Tien = getTien.TongTienCuaKH(makh);
            if(Tien>=20000000)
            {
                string sql = "update KhachHang set MaLoaiKH=1 where MaKH='" + makh + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                if(cmd.ExecuteNonQuery()>0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        public string MaKHMoi()
        {
            getConnect();
            string sql = "select COUNT(*) from KhachHang";
            SqlCommand cmd = new SqlCommand(sql, conn);
            dt.Load(cmd.ExecuteReader());
            int kq = int.Parse(dt.Rows[0][0].ToString())+1;
            return "KH" + kq;
        }
    }
}
