﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class General
    {
        public SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-D0JP2K9\SQLEXPRESS; Initial Catalog=demo2642019;Integrated Security=true");
        public DataTable dt = new DataTable();

        public SqlConnection getConnect()
        {
            if(conn.State==ConnectionState.Closed)
            {
                conn.Open();
            }
            return conn;
        }
    }
}
